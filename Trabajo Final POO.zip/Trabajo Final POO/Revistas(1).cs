﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Final_POO
{
    public class Revistas:Elementos
    {
        public Revistas() { }

        public override string MostrarInformacion()
        {
            return "CÓDIGO: " + Codigo + "\nNOMBRE DE ELEMENTO: " + nameElemento + "\nNOMBRE DE LA PERSONA A CARGO DEL ELEMENTO: " +
                namePersona + "\nNUMERO DE DOCUMENTO: " + numDocumento + "\nDIAS QUE SE PRESTO EL ELEMENTO: " + DiasEntregar +
                "\nCATEGORIA DEL ELEMENTO: " + Tipo + "\nTIPO DE PERSONA: " + tipo_Persona + "\nVALOR DE LA MULTA: " + vlr_Multa + "$";
        }
        public override string Multas()
        {
            if (DiasEntregar > 7)
            {
                msg_Multa = "USTED HA SIDO MULTADO POR NO ENTREGAR LA REVISTA EN 7 DIAS: VALOR: 3000";
            }
            return (msg_Multa);
        }
        public override double Valor_Multa()
        {
            double total = 0;
            if (DiasEntregar > 7)
            {
                total = total + 3000;
            }
            return (total);
        }
        public override string DevolverElemento()
        {
            // ----- REVISTA GOURMET -----
            if (Tipo == "Gourmet")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER LA REVISTA DE GOURMET!";
            }
            // ----- REVISTA INFANTIL -----
            else if (Tipo == "Kids")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER LA REVISTA INFANTIL: KIDS!";
            }
            // ----- REVISTA DE DIVULGACIÓN CIENTÍFICA -----
            else if (Tipo == "Conversus del ipn")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER LA REVISTA DE DIVULGACIÓN CIENTÍFICA: CONVERSUS DEL IPN!";
            }
            // ----- REVISTA INFORMATIVA -----
            else if (Tipo == "Ciencia")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER LA REVISTA INFORMATIVA: CIENCIA!";
            }
            // ----- REVISTA DE DEPORTES -----
            else if (Tipo == "Espn")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER LA REVISTA DE DEPORTES: ESPN!";
            }
            else
            {
                msg_Tipo = "ERROR. LA REVISTA NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
        public override string Reservar()
        {
            // ----- REVISTA GOURMET -----
            if (Tipo == "Gourmet")
            {
                msg_Tipo = "USTED RESERVO LA REVISTA DE GOURMET!";
            }
            // ----- REVISTA INFANTIL -----
            else if (Tipo == "Kids")
            {
                msg_Tipo = "USTED RESERVO LA REVISTA INFANTIL: KIDS!";
            }
            // ----- REVISTA DE DIVULGACIÓN CIENTÍFICA -----
            else if (Tipo == "Conversus del ipn")
            {
                msg_Tipo = "USTED RESERVO LA REVISTA DE DIVULGACIÓN CIENTÍFICA: CONVERSUS DEL IPN!";
            }
            // ----- REVISTA INFORMATIVA -----
            else if (Tipo == "Ciencia")
            {
                msg_Tipo = "USTED RESERVO LA REVISTA INFORMATIVA: CIENCIA!";
            }
            // ----- REVISTA DE DEPORTES -----
            else if (Tipo == "Espn")
            {
                msg_Tipo = "USTED RESERVO LA REVISTA DE DEPORTES: ESPN!";
            }
            else
            {
                msg_Tipo = "ERROR. LA REVISTA NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
    }
}
