﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabajo_Final_POO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        // -------------------- -------------------- 

        Libros libros = new Libros();
        Revistas revistas = new Revistas();
        Tesis tesis = new Tesis();
        Video video = new Video();
        Musica musica = new Musica();

        // -------------------- LISTS --------------------

        List<Libros> list_Libros = new List<Libros>();
        List<Revistas> list_Revistas = new List<Revistas>();
        List<Tesis> list_Tesis = new List<Tesis>();
        List<Video> list_Video = new List<Video>();
        List<Musica> list_Musica = new List<Musica>();

        // -------------------- COMBOBOX ELEMENTOS --------------------

        private void cboElemento_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboTipo.Items.Clear();

            // -------------------- COMBOBOX CLASS LIBROS --------------------

            if(cboElemento.Text == "Libros")
            {
                txtCodigoRtrar.Clear();
                txtNameRtrar.Clear();
                txtDocumentoRtrar.Clear();
                lblTipo.Visible = true;
                cboTipo.Visible = true;
                cboTipo.Items.Add("La hipotesis de amor");
                cboTipo.Items.Add("La hora del dragon");
                cboTipo.Items.Add("It");
                cboTipo.Items.Add("El principito");
                cboTipo.Items.Add("The art of cuphead");
                cboTipo.Text = "Seleccione la categoria:";
            }

            // -------------------- COMBOBOX CLASS REVISTAS --------------------

            else if(cboElemento.Text == "Revistas")
            {
                txtCodigoRtrar.Clear();
                txtNameRtrar.Clear();
                txtDocumentoRtrar.Clear();
                lblTipo.Visible = true;
                cboTipo.Visible = true;
                cboTipo.Items.Add("Gourmet");
                cboTipo.Items.Add("Kids");
                cboTipo.Items.Add("Conversus del ipn");
                cboTipo.Items.Add("Ciencia");
                cboTipo.Items.Add("Espn");
                cboTipo.Text = "Seleccione la categoria:";
            }

            // -------------------- COMBOBOX CLASS TESIS --------------------

            else if (cboElemento.Text == "Tesis")
            {
                txtCodigoRtrar.Clear();
                txtNameRtrar.Clear();
                txtDocumentoRtrar.Clear();
                lblTipo.Visible = true;
                cboTipo.Visible = true;
                cboTipo.Items.Add("De ingenieria");
                cboTipo.Items.Add("De filosofia");
                cboTipo.Items.Add("De veterinaria");
                cboTipo.Items.Add("De economia");
                cboTipo.Items.Add("De comunicacion");
                cboTipo.Text = "Seleccione la categoria:";
            }

            // -------------------- COMBOX CLASS VIDEO --------------------

            else if(cboElemento.Text == "Video")
            {
                txtCodigoRtrar.Clear();
                txtNameRtrar.Clear();
                txtDocumentoRtrar.Clear();
                lblTipo.Visible = true;
                cboTipo.Visible = true;
                cboTipo.Items.Add("After");
                cboTipo.Items.Add("Spider-man");
                cboTipo.Items.Add("Saw");
                cboTipo.Items.Add("Resident evil");
                cboTipo.Items.Add("Yu-gi-oh!");
                cboTipo.Text = "Seleccione la categoria:";
            }

            // -------------------- COMBOBOX CLASS MUSICA -------------------

            else if (cboElemento.Text == "Musica")
            {
                txtCodigoRtrar.Clear();
                txtNameRtrar.Clear();
                txtDocumentoRtrar.Clear();
                lblTipo.Visible = true;
                cboTipo.Visible = true;
                cboTipo.Items.Add("Back in black");
                cboTipo.Items.Add("Thriller");
                cboTipo.Items.Add("The chronic");
                cboTipo.Items.Add("Porque te vas");
                cboTipo.Items.Add("Stereo love");
                cboTipo.Text = "Seleccione la categoria:";
            }
            txtCodigoRtrar.Focus();
        }

        // ----------------------------------------------------------------------------------------

        // -------------------- CONTADORES DE LA CLASE LIBROS --------------------

        int contador_Lib_Rmantico = 0;
        int contador_Lib_Accion = 0;
        int contador_Lib_Terror = 0;
        int contador_Lib_Inftil = 0;
        int contador_Lib_Juegos = 0;

        // ----------------------------------------------------------------------------------------

        // -------------------- CONTADORES DE LA CLASE REVISTAS --------------------

        int contador_Rev_Gorumet = 0;
        int contador_Rev_Inftil = 0;
        int contador_Rev_Divulgacion = 0;
        int contador_Rev_Infotivas = 0;
        int contador_Rev_Deportes = 0;

        // ----------------------------------------------------------------------------------------

        // -------------------- CONTADORES DE LA CLASE TESIS --------------------

        int contador_Tes_Ing = 0;
        int contador_Tes_Fil = 0;
        int contador_Tes_Vet = 0;
        int contador_Tes_Eco = 0;
        int contador_Tes_Com = 0;

        // ----------------------------------------------------------------------------------------

        // -------------------- CONTADORES DE LA CLASE VIDEO --------------------

        int contador_Vid_Rmantico = 0;
        int contador_Vid_Accion = 0;
        int contador_Vid_Terror = 0;
        int contador_Vid_Juegos = 0;
        int contador_Vid_Anime = 0;

        // ----------------------------------------------------------------------------------------

        // -------------------- CONTADORES DE LA CLASE MUSICA --------------------

        int contador_Mus_Rock = 0;
        int contador_Mus_Pop = 0;
        int contador_Mus_Rap = 0;
        int contador_Mus_Clasica = 0;
        int contador_Mus_Electro = 0;

        // ----------------------------------------------------------------------------------------

        // -------------------- BUTTON REGISTRAR ELEMENTO --------------------

        private void btnRegistrarElemento_Click(object sender, EventArgs e)
        {
            // -------------------- CLASS LIBRO WITH ITEMS --------------------

            if(cboElemento.Text == "Libros")
            {

                // -------------------- LIBRO ROMANTICO --------------------

                if (cboTipo.Text == "La hipotesis de amor")
                {
                    libros = new Libros();
                    libros.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    libros.setnameElemento("La hipotesis de amor");
                    libros.setnamePersona(txtNameRtrar.Text);
                    libros.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    libros.setTipo("Libro Romantico");
                    libros.settipo_Persona(cboTipoPersona.Text);
                    contador_Lib_Rmantico = 3;
                    list_Libros.Add(libros);
                    MessageBox.Show("SE HA REGISTRADO EL LIBRO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO ACCION --------------------

                else if (cboTipo.Text == "La hora del dragon")
                {
                    libros = new Libros();
                    libros.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    libros.setnameElemento("La hora del dragon");
                    libros.setnamePersona(txtNameRtrar.Text);
                    libros.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    libros.setTipo("Libro Acción");
                    libros.settipo_Persona(cboTipoPersona.Text);
                    contador_Lib_Accion = 3;
                    list_Libros.Add(libros);
                    MessageBox.Show("SE HA REGISTRADO EL LIBRO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO TERROR --------------------

                else if (cboTipo.Text == "It")
                {
                    libros = new Libros();
                    libros.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    libros.setnameElemento("It");
                    libros.setnamePersona(txtNameRtrar.Text);
                    libros.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    libros.setTipo("Libro Terror");
                    libros.settipo_Persona(cboTipoPersona.Text);
                    contador_Lib_Terror = 3;
                    list_Libros.Add(libros);
                    MessageBox.Show("SE HA REGISTRADO EL LIBRO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // ------------------- LIBRO INFANTIL --------------------

                else if(cboTipo.Text == "El principito")
                {
                    libros = new Libros();
                    libros.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    libros.setnameElemento("El principito");
                    libros.setnamePersona(txtNameRtrar.Text);
                    libros.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    libros.setTipo("Libro Infantil");
                    libros.settipo_Persona(cboTipoPersona.Text);
                    contador_Lib_Inftil = 3;
                    list_Libros.Add(libros);
                    MessageBox.Show("SE HA REGISTRADO EL LIBRO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO JUEGOS --------------------

                else if (cboTipo.Text == "The art of cuphead")
                {
                    libros = new Libros();
                    libros.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    libros.setnameElemento("The art of cuphead");
                    libros.setnamePersona(txtNameRtrar.Text);
                    libros.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    libros.setTipo("Libro Juegos");
                    libros.settipo_Persona(cboTipoPersona.Text);
                    contador_Lib_Juegos = 3;
                    list_Libros.Add(libros);
                    MessageBox.Show("SE HA REGISTRADO EL LIBRO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS REVISTAS WITH ELEMENTS ----------

            else if (cboElemento.Text == "Revistas")
            {

                // -------------------- REVISTA GOURMET --------------------

                if (cboTipo.Text == "Gourmet")
                {
                    revistas = new Revistas();
                    revistas.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    revistas.setnameElemento("Gourmet");
                    revistas.setnamePersona(txtNameRtrar.Text);
                    revistas.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    revistas.setTipo("Revista Gourmet");
                    revistas.settipo_Persona(cboTipoPersona.Text);
                    contador_Rev_Gorumet = 3;
                    list_Revistas.Add(revistas);
                    MessageBox.Show("SE HA REGISTRADO LA REVISTA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFANTIL --------------------

                else if (cboTipo.Text == "Kids")
                {
                    revistas = new Revistas();
                    revistas.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    revistas.setnameElemento("Kids");
                    revistas.setnamePersona(txtNameRtrar.Text);
                    revistas.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    revistas.setTipo("Revista Infantil");
                    revistas.settipo_Persona(cboTipoPersona.Text);
                    contador_Rev_Inftil = 3;
                    list_Revistas.Add(revistas);
                    MessageBox.Show("SE HA REGISTRADO LA REVISTA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DIVULGACIÓN --------------------

                else if (cboTipo.Text=="Conversus del ipn")
                {
                    revistas = new Revistas();
                    revistas.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    revistas.setnameElemento("Conversus del ipn");
                    revistas.setnamePersona(txtNameRtrar.Text);
                    revistas.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    revistas.setTipo("Revista Divulgación");
                    revistas.settipo_Persona(cboTipoPersona.Text);
                    contador_Rev_Divulgacion = 3;
                    list_Revistas.Add(revistas);
                    MessageBox.Show("SE HA REGISTRADO LA REVISTA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFORMATIVA --------------------

                else if (cboTipo.Text == "Ciencia")
                {
                    revistas = new Revistas();
                    revistas.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    revistas.setnameElemento("Ciencia");
                    revistas.setnamePersona(txtNameRtrar.Text);
                    revistas.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    revistas.setTipo("Revista Informativa");
                    revistas.settipo_Persona(cboTipoPersona.Text);
                    contador_Rev_Infotivas = 3;
                    list_Revistas.Add(revistas);
                    MessageBox.Show("SE HA REGISTRADO LA REVISTA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DEPORTES --------------------

                else if (cboTipo.Text == "Espn")
                {
                    revistas = new Revistas();
                    revistas.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    revistas.setnameElemento("Espn");
                    revistas.setnamePersona(txtNameRtrar.Text);
                    revistas.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    revistas.setTipo("Revista Deportes");
                    revistas.settipo_Persona(cboTipoPersona.Text);
                    contador_Rev_Deportes = 3;
                    list_Revistas.Add(revistas);
                    MessageBox.Show("SE HA REGISTRADO LA REVISTA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS TESIS WITH ELEMENTS ----------

            else if (cboElemento.Text == "Tesis")
            {

                // // -------------------- TESIS INGENIERÍA --------------------

                if (cboTipo.Text == "De ingenieria")
                {
                    tesis = new Tesis();
                    tesis.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    tesis.setnameElemento("De ingenieria");
                    tesis.setnamePersona(txtNameRtrar.Text);
                    tesis.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    tesis.setTipo("Tesis Ingeniería");
                    tesis.settipo_Persona(cboTipoPersona.Text);
                    contador_Tes_Ing = 3;
                    list_Tesis.Add(tesis);
                    MessageBox.Show("SE HA REGISTRADO LA TESIS!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS FILOSOFÍA --------------------

                else if (cboTipo.Text=="De filosofia")
                {
                    tesis = new Tesis();
                    tesis.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    tesis.setnameElemento("De filosofia");
                    tesis.setnamePersona(txtNameRtrar.Text);
                    tesis.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    tesis.setTipo("Tesis Filosofía");
                    tesis.settipo_Persona(cboTipoPersona.Text);
                    contador_Tes_Fil = 3;
                    list_Tesis.Add(tesis);
                    MessageBox.Show("SE HA REGISTRADO LA TESIS!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS VETERINARIA --------------------

                else if (cboTipo.Text=="De veterinaria")
                {
                    tesis = new Tesis();
                    tesis.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    tesis.setnameElemento("De veterinaria");
                    tesis.setnamePersona(txtNameRtrar.Text);
                    tesis.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    tesis.setTipo("Tesis Veterinaria");
                    tesis.settipo_Persona(cboTipoPersona.Text);
                    contador_Tes_Vet = 3;
                    list_Tesis.Add(tesis);
                    MessageBox.Show("SE HA REGISTRADO LA TESIS!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS ECONOMÍA --------------------

                else if (cboTipo.Text=="De economia")
                {
                    tesis = new Tesis();
                    tesis.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    tesis.setnameElemento("De economia");
                    tesis.setnamePersona(txtNameRtrar.Text);
                    tesis.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    tesis.setTipo("Tesis Economía");
                    tesis.settipo_Persona(cboTipoPersona.Text);
                    contador_Tes_Eco = 3;
                    list_Tesis.Add(tesis);
                    MessageBox.Show("SE HA REGISTRADO LA TESIS!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS COMUNICACIÓN --------------------

                else if (cboTipo.Text=="De comunicacion")
                {
                    tesis = new Tesis();
                    tesis.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    tesis.setnameElemento("De comunicacion");
                    tesis.setnamePersona(txtNameRtrar.Text);
                    tesis.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    tesis.setTipo("Tesis Comunicación");
                    tesis.settipo_Persona(cboTipoPersona.Text);
                    contador_Tes_Com = 3;
                    list_Tesis.Add(tesis);
                    MessageBox.Show("SE HA REGISTRADO LA TESIS!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS VIDEO WITH ELEMENTS ----------

            else if (cboElemento.Text == "Video")
            {

                // -------------------- VIDEO ROMANTICO --------------------

                if (cboTipo.Text == "After")
                {
                    video = new Video();
                    video.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    video.setnameElemento("After");
                    video.setnamePersona(txtNameRtrar.Text);
                    video.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    video.setTipo("Video Romantico");
                    video.settipo_Persona(cboTipoPersona.Text);
                    contador_Vid_Rmantico = 3;
                    list_Video.Add(video);
                    MessageBox.Show("SE HA REGISTRADO EL VIDEO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ACCIÓN --------------------

                else if (cboTipo.Text == "Spider-man")
                {
                    video = new Video();
                    video.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    video.setnameElemento("Spider-man");
                    video.setnamePersona(txtNameRtrar.Text);
                    video.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    video.setTipo("Video Acción");
                    video.settipo_Persona(cboTipoPersona.Text);
                    contador_Vid_Accion = 3;
                    list_Video.Add(video);
                    MessageBox.Show("SE HA REGISTRADO EL VIDEO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO TERROR --------------------

                else if (cboTipo.Text == "Saw")
                {
                    video = new Video();
                    video.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    video.setnameElemento("Saw");
                    video.setnamePersona(txtNameRtrar.Text);
                    video.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    video.setTipo("Video Terror");
                    video.settipo_Persona(cboTipoPersona.Text);
                    contador_Vid_Terror = 3;
                    list_Video.Add(video);
                    MessageBox.Show("SE HA REGISTRADO EL VIDEO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO JUEGOS --------------------

                else if (cboTipo.Text=="Resident evil")
                {
                    video = new Video();
                    video.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    video.setnameElemento("Resident evil");
                    video.setnamePersona(txtNameRtrar.Text);
                    video.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    video.setTipo("Video Juegos");
                    video.settipo_Persona(cboTipoPersona.Text);
                    contador_Vid_Juegos = 3;
                    list_Video.Add(video);
                    MessageBox.Show("SE HA REGISTRADO EL VIDEO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ANIME --------------------

                else if (cboTipo.Text == "Yu-gi-oh!")
                {
                    video = new Video();
                    video.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    video.setnameElemento("Yu-gi-oh!");
                    video.setnamePersona(txtNameRtrar.Text);
                    video.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    video.setTipo("Video Anime");
                    video.settipo_Persona(cboTipoPersona.Text);
                    contador_Vid_Anime = 3;
                    list_Video.Add(video);
                    MessageBox.Show("SE HA REGISTRADO EL VIDEO!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS MUSICA WITH ELEMENTS ----------

            else if (cboElemento.Text == "Musica")
            {

                // -------------------- CD ROCK --------------------

                if (cboTipo.Text=="Back in black")
                {
                    musica = new Musica();
                    musica.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    musica.setnameElemento("Back in black");
                    musica.setnamePersona(txtNameRtrar.Text);
                    musica.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    musica.setTipo("Musica Rock");
                    musica.settipo_Persona(cboTipoPersona.Text);
                    contador_Mus_Rock = 3;
                    list_Musica.Add(musica);
                    MessageBox.Show("SE HA REGISTRADO EL CD DE MUSICA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD POP --------------------

                else if (cboTipo.Text == "Thriller")
                {
                    musica = new Musica();
                    musica.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    musica.setnameElemento("Thriller");
                    musica.setnamePersona(txtNameRtrar.Text);
                    musica.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    musica.setTipo("Musica Pop");
                    musica.settipo_Persona(cboTipoPersona.Text);
                    contador_Mus_Pop = 3;
                    list_Musica.Add(musica);
                    MessageBox.Show("SE HA REGISTRADO EL CD DE MUSICA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD RAP --------------------

                else if (cboTipo.Text == "The chronic")
                {
                    musica = new Musica();
                    musica.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    musica.setnameElemento("The chronic");
                    musica.setnamePersona(txtNameRtrar.Text);
                    musica.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    musica.setTipo("Musica Rap");
                    musica.settipo_Persona(cboTipoPersona.Text);
                    contador_Mus_Rap = 3;
                    list_Musica.Add(musica);
                    MessageBox.Show("SE HA REGISTRADO EL CD DE MUSICA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD CLASICA --------------------

                else if (cboTipo.Text == "Porque te vas")
                {
                    musica = new Musica();
                    musica.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    musica.setnameElemento("Porque te vas");
                    musica.setnamePersona(txtNameRtrar.Text);
                    musica.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    musica.setTipo("Musica Clasica");
                    musica.settipo_Persona(cboTipoPersona.Text);
                    contador_Mus_Clasica = 3;
                    list_Musica.Add(musica);
                    MessageBox.Show("SE HA REGISTRADO EL CD DE MUSICA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD ELECTRONICA --------------------

                else if (cboTipo.Text=="Stereo love")
                {
                    musica = new Musica();
                    musica.setCodigo(Convert.ToInt32(txtCodigoRtrar.Text));
                    musica.setnameElemento("Stereo love");
                    musica.setnamePersona(txtNameRtrar.Text);
                    musica.setnumDocumento(Convert.ToInt32(txtDocumentoRtrar.Text));
                    musica.setTipo("Musica Electronica");
                    musica.settipo_Persona(cboTipoPersona.Text);
                    contador_Mus_Electro = 3;
                    list_Musica.Add(musica);
                    MessageBox.Show("SE HA REGISTRADO EL CD DE MUSICA!", "MENÚ REGISTRO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCodigoRtrar.Clear();
                    txtNameRtrar.Clear();
                    txtDocumentoRtrar.Clear();
                    txtCodigoPrestar.Enabled = true;
                    btnPrestarElemento.Enabled = true;
                    txtCodigoReservar.Enabled = true;
                    btnReservarElemento.Enabled = true;
                    txtCodigoDevolver.Enabled = true;
                    btnDevolverElemento.Enabled = true;
                    txtCodigoInfo.Enabled = true;
                    btnInfoElemento.Enabled = true;
                    lblInfo.Visible = false;
                    txtDiasDevolver.Enabled = true;
                    btnMultas.Enabled = true;
                    lblMultas.Visible = false;
                    lblContadorInfo.Visible = false;
                }
            }
            
            // ------------------------------------------------------------------------------------

        }

        // ----------------------------------------------------------------------------------------

        // -------------------- BUTTON PRESTAR ELEMENTOS --------------------

        private void btnVentaElemento_Click(object sender, EventArgs e)
        {

            // -------------------- CLASS LIBROS WITH ITEMS --------------------

            if (cboElemento.Text == "Libros")
            {

                // -------------------- LIBRO ROMANTICO --------------------

                if (cboTipo.Text == "La hipotesis de amor")
                {
                    foreach(Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Lib_Rmantico == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE LIBRO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if(contador_Lib_Rmantico > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Rmantico = contador_Lib_Rmantico - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Rmantico;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO LA HIPOTESIS DE AMOR PRESTADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO ACCIÓN --------------------

                else if (cboTipo.Text == "La hora del dragon")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Lib_Accion == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE LIBRO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if(contador_Lib_Accion > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Accion = contador_Lib_Accion - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Accion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO LA HORA DEL DRAGON PRESTADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- LIBRO TERROR --------------------

                else if (cboTipo.Text == "It")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Lib_Terror == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE LIBRO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if(contador_Lib_Terror > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Terror = contador_Lib_Terror - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Terror;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO IT PRESTADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO INFANTIL --------------------

                else if(cboTipo.Text=="El principito")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Lib_Inftil == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE LIBRO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if(contador_Lib_Inftil > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Inftil = contador_Lib_Inftil - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Inftil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO EL PRINCIPITO PRESTADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO JUEGOS --------------------

                else if(cboTipo.Text=="The art of cuphead")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Lib_Juegos == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE LIBRO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Lib_Juegos > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Juegos = contador_Lib_Juegos- 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Juegos;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO THE ART OF CUPHEAD PRESTADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS REVISTAS WITH ITEMS --------------------

            else if (cboElemento.Text == "Revistas")
            {

                // -------------------- REVISTA GOURMET --------------------

                if (cboTipo.Text == "Gourmet")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if(contador_Rev_Gorumet == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA REVISTA", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Gorumet > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Gorumet = contador_Rev_Gorumet - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Gorumet;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA GOURMET PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFANTIL --------------------

                else if (cboTipo.Text == "Kids")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Rev_Inftil == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA REVISTA", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if(contador_Rev_Inftil > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Inftil = contador_Rev_Inftil - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Inftil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA KIDS PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DIVULGACIÓN -------------------

                else if(cboTipo.Text=="Conversus del ipn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Rev_Divulgacion == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA REVISTA REVISTA", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Divulgacion > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Divulgacion = contador_Rev_Divulgacion - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Divulgacion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA CONVERSUS DEL IPN PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFORMATIVA --------------------

                else if (cboTipo.Text == "Ciencia")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if(contador_Rev_Infotivas == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA REVISTA", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Infotivas > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Infotivas = contador_Rev_Infotivas - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Infotivas;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA CIENCIA PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DEPORTES --------------------

                else if (cboTipo.Text == "Espn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Rev_Deportes == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA REVISTA", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Deportes > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Deportes = contador_Rev_Deportes - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Deportes;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA ESPN PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break; 
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS TESIS WITH ITEMS ----------

            else if (cboElemento.Text == "Tesis")
            {

                // -------------------- TESIS INGENIERÍA -------------------

                if (cboTipo.Text == "De ingenieria")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Tes_Ing == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;                            
                            }
                            else if (contador_Tes_Ing > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Ing = contador_Tes_Ing - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Ing;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE INGENIERÍA PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS DE FILOSOFÍA --------------------

                else if(cboTipo.Text=="De filosofia")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Tes_Fil == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Fil > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Fil = contador_Tes_Fil - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Fil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE FILOSOFÍA PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- TESIS DE VETERINARIA -------------------

                else if(cboTipo.Text=="De veterinaria")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Tes_Vet == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Vet > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Vet = contador_Tes_Vet - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Vet;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE VETERINARIA PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- TESIS DE ECONOMÍA ------------------

                else if(cboTipo.Text=="De economia")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Tes_Eco == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Eco > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Eco = contador_Tes_Eco - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Eco;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE ECONOMÍA PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------ TESIS DE COMUNICACIÓN -------------------

                else if(cboTipo.Text=="De comunicacion")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Tes_Com == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Com > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Com = contador_Tes_Com - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Com;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE COMUNICACIÓN PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break; 
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS VIDEO WITH ITEMS ----------

            else if (cboElemento.Text == "Video")
            {

                // -------------------- VIDEO ROMANTICO --------------------

                if (cboTipo.Text == "After")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Vid_Rmantico == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE VIDEO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if(contador_Vid_Rmantico > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Rmantico = contador_Vid_Rmantico - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Rmantico;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA AFTER PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ACCIÓN --------------------

                else if (cboTipo.Text == "Spider-man")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if(contador_Vid_Accion == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE VIDEO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Accion > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Accion = contador_Vid_Accion - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Accion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA SPIDER-MAN PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO TERROR -------------------

                else if (cboTipo.Text == "Saw")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Vid_Terror == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTA VIDEO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Terror > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Terror = contador_Vid_Terror - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Terror;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA SAW PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO JUEGO --------------------

                else if(cboTipo.Text=="Resident evil")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Vid_Juegos == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE VIDEO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Juegos > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Juegos = contador_Vid_Juegos - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Juegos;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA RESIDENT EVIL PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ANIME --------------------

                else if (cboTipo.Text == "Yu-gi-oh!")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Vid_Anime == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE VIDEO", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Anime > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Anime = contador_Vid_Anime - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Anime;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA YU-GI-OH! PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS MUSICA WITH ITEMS --------------------

            else if (cboElemento.Text == "Musica")
            {

                // -------------------- CD ROCK --------------------

                if(cboTipo.Text=="Back in black")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Mus_Rock == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE CD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Rock > 0)
                            {
                                MessageBox.Show("ARTICULO CD DE MUSICA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Rock = contador_Mus_Rock - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Rock;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA BACK IN BLACK PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- CD POP --------------------

                else if (cboTipo.Text == "Thriller")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Mus_Pop == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE CD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Pop > 0)
                            {
                                MessageBox.Show("ARTICULO CD DE MUSICA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Pop = contador_Mus_Pop - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Pop;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA THRILLER PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD RAP --------------------

                else if(cboTipo.Text=="The chronic")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Mus_Rap == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE CD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Rap > 0)
                            {
                                MessageBox.Show("ARTICULO CD DE MUSICA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Rap = contador_Mus_Rap - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Rap;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA THE CHRONIC PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD CLASICA --------------------

                else if(cboTipo.Text=="Porque te vas")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Mus_Clasica == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE CD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Clasica > 0)
                            {
                                MessageBox.Show("ARTICULO CD DE MUSICA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Clasica = contador_Mus_Clasica - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Clasica;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA PORQUE TE VAS PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD ELECTRONICA --------------------

                else if(cboTipo.Text=="Stereo love")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoPrestar.Text))
                        {
                            if (contador_Mus_Electro == 0)
                            {
                                MessageBox.Show("NO HAY MAS CANTIDADES DISPONIBLES PARA PRESTAR ESTE CD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Electro > 0)
                            {
                                MessageBox.Show("ARTICULO CD DE MUSICA PRESTADO CORRECTAMENTE!", "MENÚ PRESTAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Electro = contador_Mus_Electro - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Electro;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA STEREO LOVE PRESTADA!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }
        }

        // ------------------------------------------------------------

        // ---------- BUTTON RESERVAR ELEMENTS ----------

        private void btnReservarElemento_Click(object sender, EventArgs e)
        {
            // -------------------- CLASS LIBROS WITH ITEMS --------------------

            if (cboElemento.Text == "Libros")
            {

                // -------------------- LIBRO ROMANTICO --------------------

                if (cboTipo.Text == "La hipotesis de amor")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Lib_Rmantico == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LIBROS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Lib_Rmantico > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Rmantico = contador_Lib_Rmantico - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Rmantico;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO LA HIPOTESIS DE AMOR RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO ACCIÓN --------------------

                else if (cboTipo.Text == "La hora del dragon")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Lib_Accion == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LIBROS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                                break;
                            }
                            else if (contador_Lib_Accion > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Accion = contador_Lib_Accion - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Accion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO LA HORA DEL DRAGON RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- LIBRO TERROR --------------------

                else if (cboTipo.Text == "It")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Lib_Terror == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LIBROS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Lib_Terror > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Terror = contador_Lib_Terror - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Terror;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO IT RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO INFANTIL --------------------

                else if (cboTipo.Text == "El principito")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Lib_Inftil == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LIBROS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Lib_Inftil > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Inftil = contador_Lib_Inftil - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Inftil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO EL PRINCIPITO RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO JUEGOS --------------------

                else if (cboTipo.Text == "The art of cuphead")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Lib_Juegos == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LIBROS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Lib_Juegos > 0)
                            {
                                MessageBox.Show("ARTICULO LIBROS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Lib_Juegos = contador_Lib_Juegos - 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Juegos;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LIBRO THE ART OF CUPHEAD RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS REVISTAS WITH ITEMS --------------------

            else if (cboElemento.Text == "Revistas")
            {

                // -------------------- REVISTA GOURMET --------------------

                if (cboTipo.Text == "Gourmet")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Rev_Gorumet == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE REVISTAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Gorumet > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Gorumet = contador_Rev_Gorumet - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Gorumet;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA GOURMET RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFANTIL --------------------

                else if (cboTipo.Text == "Kids")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Rev_Inftil == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE REVISTAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Inftil > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Inftil = contador_Rev_Inftil - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Inftil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA KIDS RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DIVULGACIÓN -------------------

                else if (cboTipo.Text == "Conversus del ipn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Rev_Divulgacion == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE REVISTAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Divulgacion > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Divulgacion = contador_Rev_Divulgacion - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Divulgacion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA CONVERSUS DEL IPN RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFORMATIVA --------------------

                else if (cboTipo.Text == "Ciencia")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Rev_Infotivas == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE REVISTAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Infotivas > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Infotivas = contador_Rev_Infotivas - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Infotivas;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA CIENCIA RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DEPORTES --------------------

                else if (cboTipo.Text == "Espn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Rev_Deportes == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE REVISTAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Rev_Deportes > 0)
                            {
                                MessageBox.Show("ARTICULO REVISTA RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Rev_Deportes = contador_Rev_Deportes - 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Deportes;
                                lblInfo.Visible = true;
                                lblInfo.Text = "REVISTA ESPN RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS TESIS WITH ITEMS ----------

            else if (cboElemento.Text == "Tesis")
            {

                // -------------------- TESIS INGENIERÍA -------------------

                if (cboTipo.Text == "De ingenieria")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Tes_Ing == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LAS TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Ing > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Ing = contador_Tes_Ing - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Ing;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE INGENIERÍA RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS DE FILOSOFÍA --------------------

                else if (cboTipo.Text == "De filosofia")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Tes_Fil == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LAS TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Fil > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Fil = contador_Tes_Fil - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Fil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE FILOSOFÍA RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- TESIS DE VETERINARIA -------------------

                else if (cboTipo.Text == "De veterinaria")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Tes_Vet == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LAS TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Vet > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Vet = contador_Tes_Vet - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Vet;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE VETERINARIA RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- TESIS DE ECONOMÍA ------------------

                else if (cboTipo.Text == "De economia")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Tes_Eco == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LAS TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Eco > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Eco = contador_Tes_Eco - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Eco;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE ECONOMÍA RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------ TESIS DE COMUNICACIÓN -------------------

                else if (cboTipo.Text == "De comunicacion")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Tes_Com == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE LAS TESIS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Tes_Com > 0)
                            {
                                MessageBox.Show("ARTICULO TESIS RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Tes_Com = contador_Tes_Com - 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Com;
                                lblInfo.Visible = true;
                                lblInfo.Text = "TESIS DE COMUNICACIÓN RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS VIDEO WITH ITEMS ----------

            else if (cboElemento.Text == "Video")
            {

                // -------------------- VIDEO ROMANTICO --------------------

                if (cboTipo.Text == "After")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Vid_Rmantico == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE VIDEOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Rmantico > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Rmantico = contador_Vid_Rmantico - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Rmantico;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA AFTER RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ACCIÓN --------------------

                else if (cboTipo.Text == "Spider-man")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Vid_Accion == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE VIDEOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Accion > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Accion = contador_Vid_Accion - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Accion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA SPIDER-MAN RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO TERROR -------------------

                else if (cboTipo.Text == "Saw")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Vid_Terror == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE VIDEOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Terror > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Terror = contador_Vid_Terror - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Terror;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA SAW RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO JUEGO --------------------

                else if (cboTipo.Text == "Resident evil")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Vid_Juegos == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE VIDEOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Juegos > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Juegos = contador_Vid_Juegos - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Juegos;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA RESIDENT EVIL RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ANIME --------------------

                else if (cboTipo.Text == "Yu-gi-oh!")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Vid_Anime == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE VIDEOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Vid_Anime > 0)
                            {
                                MessageBox.Show("ARTICULO VIDEO RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Vid_Anime = contador_Vid_Anime - 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Anime;
                                lblInfo.Visible = true;
                                lblInfo.Text = "VIDEO PELICULA YU-GI-OH! RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS MUSICA WITH ITEMS --------------------

            else if (cboElemento.Text == "Musica")
            {

                // -------------------- CD ROCK --------------------

                if (cboTipo.Text == "Back in black")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Mus_Rock == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE CD´S", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Rock > 0)
                            {
                                MessageBox.Show("ARTICULO CD RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Rock = contador_Mus_Rock - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Rock;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA BACK IN BLACK RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- CD POP --------------------

                else if (cboTipo.Text == "Thriller")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Mus_Pop == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE CD´S", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Pop > 0)
                            {
                                MessageBox.Show("ARTICULO CD RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Pop = contador_Mus_Pop - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Pop;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA THRILLER RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD RAP --------------------

                else if (cboTipo.Text == "The chronic")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Mus_Rap == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE CD´S", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Rap > 0)
                            {
                                MessageBox.Show("ARTICULO CD RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Rap = contador_Mus_Rap - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Rap;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA THE CHRONIC RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD CLASICA --------------------

                else if (cboTipo.Text == "Porque te vas")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Mus_Clasica == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE CD´S", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Clasica > 0)
                            {
                                MessageBox.Show("ARTICULO CD RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Clasica = contador_Mus_Clasica - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Clasica;; 
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA PORQUE TE VAS RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD ELECTRONICA --------------------

                else if (cboTipo.Text == "Stereo love")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoReservar.Text))
                        {
                            if (contador_Mus_Electro == 0)
                            {
                                MessageBox.Show("EN ESTE MOMENTO NO ESTÁ DISPONIBLE LA RESERVA DE CD´S", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                            else if (contador_Mus_Electro > 0)
                            {
                                MessageBox.Show("ARTICULO CD RESERVADO!", "MENÚ RESERVAR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lblContadorInfo.Visible = true;
                                contador_Mus_Electro = contador_Mus_Electro - 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Electro;
                                lblInfo.Visible = true;
                                lblInfo.Text = "CD DE MUSICA STEREO LOVE RESERVADO!";
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                        }
                    }
                }
            }
        }

        // ----------------------------------------------------------------------------------------

        // -------------------- BUTTON DEVOLVER ELEMENTO --------------------

        private void btnDevolverElemento_Click(object sender, EventArgs e)
        {
            // -------------------- CLASS LIBROS WITH ITEMS --------------------

            if (cboElemento.Text == "Libros")
            {

                // -------------------- LIBRO ROMANTICO --------------------

                if (cboTipo.Text == "La hipotesis de amor")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if(contador_Lib_Rmantico < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL LIBRO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lib.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Lib_Rmantico = contador_Lib_Rmantico + 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Rmantico;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL LIBRO LA HIPOTESIS DE AMOR VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    lib.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("LIBROS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO ACCIÓN --------------------

                else if (cboTipo.Text == "La hora del dragon")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Lib_Accion < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL LIBRO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lib.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Lib_Accion = contador_Lib_Accion + 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Accion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL LIBRO LA HORA DEL DRAGON VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    lib.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("LIBROS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- LIBRO TERROR --------------------

                else if (cboTipo.Text == "It")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Lib_Terror < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL LIBRO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lib.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Lib_Terror = contador_Lib_Terror + 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Terror;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL LIBRO IT VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    lib.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("LIBROS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO INFANTIL --------------------

                else if (cboTipo.Text == "El principito")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Lib_Inftil < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL LIBRO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lib.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Lib_Inftil = contador_Lib_Inftil + 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Inftil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL LIBRO EL PRINCIPITO VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    lib.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("LIBROS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO JUEGOS --------------------

                else if (cboTipo.Text == "The art of cuphead")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Lib_Juegos < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL LIBRO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lib.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Lib_Juegos = contador_Lib_Juegos + 1;
                                lblContadorInfo.Text = "LIBROS DISPONIBLES: " + contador_Lib_Juegos;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL LIBRO THE ART OF CUPHEAD VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    lib.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("LIBROS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS REVISTAS WITH ITEMS --------------------

            else if (cboElemento.Text == "Revistas")
            {

                // -------------------- REVISTA GOURMET --------------------

                if (cboTipo.Text == "Gourmet")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Rev_Gorumet < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA REVISTA!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                rev.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Rev_Gorumet = contador_Rev_Gorumet + 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Gorumet;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA REVISTA GOURMET VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    rev.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("REVISTAS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFANTIL --------------------

                else if (cboTipo.Text == "Kids")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Rev_Inftil < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA REVISTA!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                rev.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Rev_Inftil = contador_Rev_Inftil + 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Inftil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA REVISTA KIDS VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    rev.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("REVISTAS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DIVULGACIÓN -------------------

                else if (cboTipo.Text == "Conversus del ipn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Rev_Divulgacion < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA REVISTA!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                rev.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Rev_Divulgacion = contador_Rev_Divulgacion + 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Divulgacion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA REVISTA CONVERSUS DEL IPN VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    rev.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("REVISTAS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFORMATIVA --------------------

                else if (cboTipo.Text == "Ciencia")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Rev_Infotivas < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA REVISTA!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                rev.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Rev_Infotivas = contador_Rev_Infotivas + 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Infotivas;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA REVISTA CIENCIA VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    rev.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("REVISTAS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DEPORTES --------------------

                else if (cboTipo.Text == "Espn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Rev_Deportes < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA REVISTA!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                rev.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Rev_Deportes = contador_Rev_Deportes + 1;
                                lblContadorInfo.Text = "REVISTAS DISPONIBLES: " + contador_Rev_Deportes;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA REVISTA ESPN VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    rev.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("REVISTAS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS TESIS WITH ITEMS ----------

            else if (cboElemento.Text == "Tesis")
            {

                // -------------------- TESIS INGENIERÍA -------------------

                if (cboTipo.Text == "De ingenieria")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Tes_Ing < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA TESIS!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tes.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Tes_Ing = contador_Tes_Ing + 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Ing;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA TESIS DE INGENIERÍA VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    tes.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("TESIS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- TESIS DE FILOSOFÍA --------------------

                else if (cboTipo.Text == "De filosofia")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Tes_Fil < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA TESIS!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tes.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Tes_Fil = contador_Tes_Fil + 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Fil;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA TESIS DE FILOSOFÍA VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    tes.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("TESIS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- TESIS DE VETERINARIA -------------------

                else if (cboTipo.Text == "De veterinaria")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Tes_Vet < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA TESIS!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tes.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Tes_Vet = contador_Tes_Vet + 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Vet;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA TESIS DE VETERINARIA VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    tes.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("TESIS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- TESIS DE ECONOMÍA ------------------

                else if (cboTipo.Text == "De economia")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Tes_Eco < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA TESIS!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tes.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Tes_Eco = contador_Tes_Eco + 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Eco;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA TESIS DE ECONOMÍA VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    tes.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("TESIS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------ TESIS DE COMUNICACIÓN -------------------

                else if (cboTipo.Text == "De comunicacion")
                {
                    foreach (Tesis tes in list_Tesis)
                    {
                        if (tes.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Tes_Com < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER LA TESIS!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tes.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Tes_Com = contador_Tes_Com + 1;
                                lblContadorInfo.Text = "TESIS DISPONIBLES: " + contador_Tes_Com;
                                lblInfo.Visible = true;
                                lblInfo.Text = "LA TESIS DE COMUNICACIÓN VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    tes.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("TESIS YA COMPLETAS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------

            // ---------- CLASS VIDEO WITH ITEMS ----------

            else if (cboElemento.Text == "Video")
            {

                // -------------------- VIDEO ROMANTICO --------------------

                if (cboTipo.Text == "After")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Vid_Rmantico < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL VIDEO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                vid.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Vid_Rmantico = contador_Vid_Rmantico + 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Rmantico;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL VIDEO AFTER VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    vid.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("VIDEOS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ACCIÓN --------------------

                else if (cboTipo.Text == "Spider-man")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Vid_Accion < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL VIDEO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                vid.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Vid_Accion = contador_Vid_Accion + 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Accion;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL VIDEO SPIDER-MAN VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    vid.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("VIDEOS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO TERROR -------------------

                else if (cboTipo.Text == "Saw")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Vid_Terror < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL VIDEO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                vid.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Vid_Terror = contador_Vid_Terror + 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Terror;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL VIDEO SAW VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    vid.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("VIDEOS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO JUEGO --------------------

                else if (cboTipo.Text == "Resident evil")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Vid_Juegos < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL VIDEO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                vid.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Vid_Juegos = contador_Vid_Juegos + 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Juegos;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL VIDEO RESIDENT EVIL VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    vid.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("VIDEOS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- VIDEO ANIME --------------------

                else if (cboTipo.Text == "Yu-gi-oh!")
                {
                    foreach (Video vid in list_Video)
                    {
                        if (vid.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Vid_Anime < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL VIDEO!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                vid.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Vid_Anime = contador_Vid_Anime + 1;
                                lblContadorInfo.Text = "VIDEOS DISPONIBLES: " + contador_Vid_Anime;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL VIDEO YU-GI-OH! VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    vid.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("VIDEOS YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS MUSICA WITH ITEMS --------------------

            else if (cboElemento.Text == "Musica")
            {

                // -------------------- CD ROCK --------------------

                if (cboTipo.Text == "Back in black")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Mus_Rock < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL CD!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                mus.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Mus_Rock = contador_Mus_Rock + 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Rock;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL CD BACK IN BLACK VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    mus.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("CD´S YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // ------------------- CD POP --------------------

                else if (cboTipo.Text == "Thriller")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Mus_Pop < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL CD!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                mus.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Mus_Pop = contador_Mus_Pop + 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Pop;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL CD THRILLER VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    mus.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("CD´S YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD RAP --------------------

                else if (cboTipo.Text == "The chronic")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Mus_Rap < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL CD!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                mus.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Mus_Rap = contador_Mus_Rap + 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Rap;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL CD THE CHRONIC VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    mus.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("CD´S YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD CLASICA --------------------

                else if (cboTipo.Text == "Porque te vas")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Mus_Clasica < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL CD!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                mus.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Mus_Clasica = contador_Mus_Clasica + 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Clasica;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL CD PORQUE TE VAS VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    mus.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("CD´S YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- CD ELECTRONICA --------------------

                else if (cboTipo.Text == "Stereo love")
                {
                    foreach (Musica mus in list_Musica)
                    {
                        if (mus.getCodigo() == Convert.ToInt32(txtCodigoDevolver.Text))
                        {
                            if (contador_Mus_Electro < 3)
                            {
                                MessageBox.Show("GRACIAS POR DEVOLVER EL CD!", "MENÚ DEVOLVER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                mus.setDiasEntregar(Convert.ToInt32(txtDiasDevolver.Text));
                                lblContadorInfo.Visible = true;
                                contador_Mus_Electro = contador_Mus_Electro + 1;
                                lblContadorInfo.Text = "CD´S DISPONIBLES: " + contador_Mus_Electro;
                                lblInfo.Visible = true;
                                lblInfo.Text = "EL CD STEREO LOVE VOLVIO A SU LUGAR!";
                                if (Convert.ToInt32(txtDiasDevolver.Text) > 6)
                                {
                                    MessageBox.Show("USTED HA SIDO MULTADO", "MENÚ MULTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    mus.setvlr_Multa(10000);
                                    lblMultas.Visible = true;
                                    lblMultas.Text = "MULTA DE 10000$ ";
                                }
                                txtCodigoPrestar.Clear();
                                txtCodigoReservar.Clear();
                                txtCodigoDevolver.Clear();
                                txtCodigoInfo.Clear();
                                txtDiasDevolver.Clear();
                                break;
                            }
                            else
                            {
                                MessageBox.Show("CD´S YA COMPLETOS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                break;
                            }
                        }
                    }
                }
            }
        }

        // ----------------------------------------------------------------------------------------

        // -------------------- MENU DE MULTAS --------------------

        private void button1_Click(object sender, EventArgs e)
        {
            lblInfo.Visible = true;
            lblInfo.Text = "MENU DE MULTAS" + 
                "\n1. DEVOLVER EL ELEMENTO DESPUES DE 6 DIAS = 10000$";
        }

        // ----------------------------------------------------------------------------------------

        // -------------------- BUTTON MOSTRAR INFORMACIÓN --------------------

        private void btnInfoElemento_Click(object sender, EventArgs e)
        {

            // -------------------- CLASS LIBROS --------------------

            if (cboElemento.Text == "Libros")
            {

                // ------------------- LIBRO ROMANTICO --------------------

                if(cboTipo.Text=="La hipotesis de amor")
                {
                    foreach(Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = lib.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        } 
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO ACCIÓN --------------------

                else if (cboTipo.Text == "La hora del dragon")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = lib.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO TERROR --------------------

                else if (cboTipo.Text == "It")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = lib.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO INFANTIL --------------------

                else if (cboTipo.Text == "El principito")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = lib.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- LIBRO VIDEOJUEGOS --------------------

                else if (cboTipo.Text == "The art of cuphead")
                {
                    foreach (Libros lib in list_Libros)
                    {
                        if (lib.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = lib.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------

            // -------------------- CLASS REVISTAS ---------------------

            else if (cboElemento.Text == "Revistas")
            {

                // -------------------- REVISTA GOURMET --------------------

                if (cboTipo.Text == "Gourmet")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = rev.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // --------------------- REVISTA INFANTIL --------------------

                else if (cboTipo.Text == "Kids")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = rev.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DIVULGACIÓN --------------------

                else if (cboTipo.Text == "Conversus del ipn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = rev.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA INFORMATIVA --------------------

                else if (cboTipo.Text == "Ciencia")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = rev.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }

                // --------------------------------------------------------------------------------

                // -------------------- REVISTA DEPORTES --------------------

                else if (cboTipo.Text == "Espn")
                {
                    foreach (Revistas rev in list_Revistas)
                    {
                        if (rev.getCodigo() == Convert.ToInt32(txtCodigoInfo.Text))
                        {
                            lblInfo.Visible = true;
                            lblInfo.Text = rev.MostrarInformacion();
                            txtCodigoRtrar.Clear();
                            txtCodigoPrestar.Clear();
                            txtCodigoReservar.Clear();
                            txtCodigoDevolver.Clear();
                            txtCodigoInfo.Clear();
                            txtDiasDevolver.Clear();
                            txtNameRtrar.Clear();
                            txtDocumentoRtrar.Clear();
                            break;
                        }
                    }
                }
            }
        }

        // ----------------------------------------------------------------------------------------

        private void pnelReservarElemento_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cboTipoPersona_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
