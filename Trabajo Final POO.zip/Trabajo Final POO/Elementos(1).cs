﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Final_POO
{
    public abstract class Elementos
    {
        protected int Codigo;
        protected string nameElemento;
        protected string namePersona;
        protected int numDocumento;
        protected string Tipo;
        protected string tipo_Persona;
        protected string Multa;
        protected double vlr_Multa;
        protected string msg_Multa;
        protected int DiasEntregar;
        protected string msg_Tipo;

        public Elementos() { }

        public Elementos(int codigo, string nameelemento, string namepersona, int numdocumento, string tipo, string tipo_persona, string multa, double vlr_multa, string msg_multa, int diasentregar, string msg_tipo)
        {
            Codigo = codigo;
            nameElemento = nameelemento;
            namePersona = namepersona;
            numDocumento = numdocumento;
            Tipo = tipo;
            tipo_Persona = tipo_persona;
            Multa = multa;
            vlr_Multa = vlr_multa;
            msg_Multa = msg_multa;
            DiasEntregar = diasentregar;
            msg_Tipo = msg_tipo;
        }

        public void setCodigo(int codigo) { this.Codigo = codigo; }
        public void setnameElemento(string nameelemento) { this.nameElemento = nameelemento; }
        public void setnamePersona(string namepersona) { this.namePersona = namepersona; }
        public void setnumDocumento(int numdocumento) { this.numDocumento = numdocumento; }
        public void setTipo(string tipo) { this.Tipo = tipo; }
        public void settipo_Persona(string tipo_persona) { this.tipo_Persona = tipo_persona; }
        public void setMulta(string multa) { this.Multa = multa; }
        public void setvlr_Multa(double vlr_multa) { this.vlr_Multa = vlr_multa; }
        public void setDiasEntregar(int diasentregar) { this.DiasEntregar = diasentregar; }

        public int getCodigo() { return Codigo; }
        public string getnameElemento() { return nameElemento; }
        public string getnamePersona() { return namePersona; }
        public int getnumDocumento() { return numDocumento; }
        public string getTipo() { return Tipo; }
        public string gettipo_Persona() { return tipo_Persona; }
        public string getMulta() { return Multa; }
        public double getvlr_Multa() { return vlr_Multa; }
        public string getmsg_Multa() { return msg_Multa; }
        public int getDiasEntregar() { return DiasEntregar; }
        public string getmsg_Tipo() { return msg_Tipo; }

        public abstract string MostrarInformacion();
        public abstract string Multas();
        public abstract double Valor_Multa();
        public abstract string DevolverElemento();
        public abstract string Reservar();



    }
}
