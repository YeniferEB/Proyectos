﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Final_POO
{
    public class Libros:Elementos
    {
        public Libros() { }

        public override string MostrarInformacion()
        {
            return "CÓDIGO: " + Codigo + "\nNOMBRE DE ELEMENTO: " + nameElemento + "\nNOMBRE DE LA PERSONA A CARGO DEL ELEMENTO: " +
                namePersona + "\nNUMERO DE DOCUMENTO: " + numDocumento + "\nDIAS QUE SE PRESTO EL ELEMENTO: " + DiasEntregar +
                "\nCATEGORIA DEL ELEMENTO: " + Tipo + "\nTIPO DE PERSONA: " + tipo_Persona + "\nVALOR DE LA MULTA: " + vlr_Multa + "$";
        }

        public override string Multas()
        {
            if(DiasEntregar > 7)
            {
                msg_Multa = "USTED HA SIDO MULTADO POR NO ENTREGAR EL LIBRO EN 7 DIAS: VALOR: 5000";
            }
            return (msg_Multa);
        }

        public override double Valor_Multa()
        {
            double total = 0;
            if (DiasEntregar > 7)
            {
                total = total + 5000;
            }
            return (total);
        }

        public override string DevolverElemento()
        {
            // ----- LIBRO ROMANTICO -----
            if(Tipo == "La hipotesis de amor")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL LIBRO ROMANTICO: LA HIPOTESIS DE AMOR!";
            }
            // ----- LIBRO DE ACCIÓN -----
            else if (Tipo == "La hora del dragon")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL LIBRO DE ACCION: LA HORA DEL DRAGON!";
            }
            // ----- LIBRO DE TERROR -----
            else if (Tipo == "It")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL LIBRO DE TERROR: IT!";
            }
            // ----- LIBRO INFANTIL -----
            else if (Tipo == "El principito")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL LIBRO INFANTIL: EL PRINCIPITO!";
            }
            // ----- LIBRO DE VIDEOJUEGOS -----
            else if (Tipo == "The art of cuphead")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL LIBRO DE VIDEOJUEGOS: THE ART OF CUPHEAD!";
            }
            else
            {
                msg_Tipo = "ERROR. EL LIBRO NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }

        public override string Reservar()
        {
            // ----- LIBRO ROMANTICO -----
            if (Tipo == "La hipotesis de amor")
            {
                msg_Tipo = "USTED RESERVO EL LIBRO ROMANTICO: LA HIPOTESIS DE AMOR!";
            }
            // ----- LIBRO DE ACCIÓN -----
            else if (Tipo == "La hora del dragon")
            {
                msg_Tipo = "USTED RESERVO EL LIBRO DE ACCION: LA HORA DEL DRAGON!";
            }
            // ----- LIBRO DE TERROR -----
            else if (Tipo == "It")
            {
                msg_Tipo = "USTED RESERVO EL LIBRO DE TERROR: IT!";
            }
            // ----- LIBRO INFANTIL -----
            else if (Tipo == "El principito")
            {
                msg_Tipo = "USTED RESERVO EL LIBRO INFANTIL: EL PRINCIPITO!";
            }
            // ----- LIBRO DE VIDEOJUEGOS -----
            else if (Tipo == "The art of cuphead")
            {
                msg_Tipo = "USTED RESERVO EL LIBRO DE VIDEOJUEGOS: THE ART OF CUPHEAD!";
            }
            else
            {
                msg_Tipo = "ERROR. EL LIBRO NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
    }
}
