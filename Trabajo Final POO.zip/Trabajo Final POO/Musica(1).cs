﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Final_POO
{
    public class Musica:Elementos
    {
        public Musica() { }

        public override string MostrarInformacion()
        {
            return "CÓDIGO: " + Codigo + "\nNOMBRE DE ELEMENTO: " + nameElemento + "\nNOMBRE DE LA PERSONA A CARGO DEL ELEMENTO: " +
                namePersona + "\nNUMERO DE DOCUMENTO: " + numDocumento + "\nDIAS QUE SE PRESTO EL ELEMENTO: " + DiasEntregar +
                "\nCATEGORIA DEL ELEMENTO: " + Tipo + "\nTIPO DE PERSONA: " + tipo_Persona + "\nVALOR DE LA MULTA: " + vlr_Multa + "$";
        }
        public override string Multas()
        {
            if (DiasEntregar > 7)
            {
                msg_Multa = "USTED HA SIDO MULTADO POR NO ENTREGAR EL DISCO EN 7 DIAS: VALOR: 10000";
            }
            return (msg_Multa);
        }
        public override double Valor_Multa()
        {
            double total = 0;
            if (DiasEntregar > 7)
            {
                total = total + 10000;
            }
            return (total);
        }
        public override string DevolverElemento()
        {
            // ----- CD DE ROCK -----
            if (Tipo == "Back in black")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL CD DE ROCK: BACK IN BLACK!";
            }
            // ----- CD DE POP -----
            else if (Tipo == "Thriller")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL CD DE POP: THRILLER!";
            }
            // ----- CD DE RAP -----
            else if (Tipo == "The chronic")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL CD DE RAP: THE CHRONIC!";
            }
            // ----- CD DE CLASICA -----
            else if (Tipo == "Porque te vas")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL CD DE CLASICA: PORQUE TE VAS!";
            }
            // ----- CD DE ELECTRO -----
            else if (Tipo == "Stereo love")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL CD DE ELECTRONICA: STEREO LOVE!";
            }
            else
            {
                msg_Tipo = "ERROR. EL CD NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
        public override string Reservar()
        {
            // ----- CD DE ROCK -----
            if (Tipo == "Back in black")
            {
                msg_Tipo = "USTED RESERVO EL CD DE ROCK: BACK IN BLACK!";
            }
            // ----- CD DE POP -----
            else if (Tipo == "Thriller")
            {
                msg_Tipo = "USTED RESERVO EL CD DE POP: THRILLER!";
            }
            // ----- CD DE RAP -----
            else if (Tipo == "The chronic")
            {
                msg_Tipo = "USTED RESERVO EL CD DE RAP: THE CHRONIC!";
            }
            // ----- CD DE CLASICA -----
            else if (Tipo == "Porque te vas")
            {
                msg_Tipo = "USTED RESERVO EL CD DE CLASICA: PORQUE TE VAS!";
            }
            // ----- CD DE ELECTRO -----
            else if (Tipo == "Stereo love")
            {
                msg_Tipo = "USTED RESERVO EL CD DE ELECTRONICA: STEREO LOVE!";
            }
            else
            {
                msg_Tipo = "ERROR. EL CD NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
    }
}
