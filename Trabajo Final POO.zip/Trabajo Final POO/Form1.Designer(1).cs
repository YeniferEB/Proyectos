﻿namespace Trabajo_Final_POO
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboElemento = new System.Windows.Forms.ComboBox();
            this.btnRegistrarElemento = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboTipoPersona = new System.Windows.Forms.ComboBox();
            this.lblTipoPersona = new System.Windows.Forms.Label();
            this.lblTipo = new System.Windows.Forms.Label();
            this.cboTipo = new System.Windows.Forms.ComboBox();
            this.txtDocumentoRtrar = new System.Windows.Forms.TextBox();
            this.lblidRtrar = new System.Windows.Forms.Label();
            this.txtNameRtrar = new System.Windows.Forms.TextBox();
            this.lblNameRtrar = new System.Windows.Forms.Label();
            this.txtCodigoRtrar = new System.Windows.Forms.TextBox();
            this.lblCodigoRtrar = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.pnelPrestarElemento = new System.Windows.Forms.Panel();
            this.btnPrestarElemento = new System.Windows.Forms.Button();
            this.txtCodigoPrestar = new System.Windows.Forms.TextBox();
            this.lblCodigoVenta = new System.Windows.Forms.Label();
            this.pnelReservarElemento = new System.Windows.Forms.Panel();
            this.btnReservarElemento = new System.Windows.Forms.Button();
            this.txtCodigoReservar = new System.Windows.Forms.TextBox();
            this.lblCodigoReservar = new System.Windows.Forms.Label();
            this.pnelMostrarElemento = new System.Windows.Forms.Panel();
            this.lblMultas = new System.Windows.Forms.Label();
            this.lblContadorInfo = new System.Windows.Forms.Label();
            this.btnMultas = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnInfoElemento = new System.Windows.Forms.Button();
            this.txtCodigoInfo = new System.Windows.Forms.TextBox();
            this.lblCodigoInfo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pnelDevolverElemento = new System.Windows.Forms.Panel();
            this.txtDiasDevolver = new System.Windows.Forms.TextBox();
            this.lblDiasDevolver = new System.Windows.Forms.Label();
            this.btnDevolverElemento = new System.Windows.Forms.Button();
            this.txtCodigoDevolver = new System.Windows.Forms.TextBox();
            this.lblCodigoDevolver = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnelPrestarElemento.SuspendLayout();
            this.pnelReservarElemento.SuspendLayout();
            this.pnelMostrarElemento.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            this.pnelDevolverElemento.SuspendLayout();
            this.SuspendLayout();
            // 
            // cboElemento
            // 
            this.cboElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboElemento.FormattingEnabled = true;
            this.cboElemento.Items.AddRange(new object[] {
            "Libros",
            "Revistas",
            "Tesis",
            "Video",
            "Musica"});
            this.cboElemento.Location = new System.Drawing.Point(3, 3);
            this.cboElemento.Name = "cboElemento";
            this.cboElemento.Size = new System.Drawing.Size(312, 24);
            this.cboElemento.TabIndex = 0;
            this.cboElemento.Text = "Seleccione el elemento que desea llevar:";
            this.cboElemento.SelectedIndexChanged += new System.EventHandler(this.cboElemento_SelectedIndexChanged);
            // 
            // btnRegistrarElemento
            // 
            this.btnRegistrarElemento.BackColor = System.Drawing.Color.White;
            this.btnRegistrarElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarElemento.Location = new System.Drawing.Point(321, 4);
            this.btnRegistrarElemento.Name = "btnRegistrarElemento";
            this.btnRegistrarElemento.Size = new System.Drawing.Size(157, 23);
            this.btnRegistrarElemento.TabIndex = 1;
            this.btnRegistrarElemento.Text = "Registrar Elemento";
            this.btnRegistrarElemento.UseVisualStyleBackColor = false;
            this.btnRegistrarElemento.Click += new System.EventHandler(this.btnRegistrarElemento_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cboTipoPersona);
            this.panel1.Controls.Add(this.lblTipoPersona);
            this.panel1.Controls.Add(this.lblTipo);
            this.panel1.Controls.Add(this.cboTipo);
            this.panel1.Controls.Add(this.txtDocumentoRtrar);
            this.panel1.Controls.Add(this.lblidRtrar);
            this.panel1.Controls.Add(this.txtNameRtrar);
            this.panel1.Controls.Add(this.lblNameRtrar);
            this.panel1.Controls.Add(this.txtCodigoRtrar);
            this.panel1.Controls.Add(this.lblCodigoRtrar);
            this.panel1.Location = new System.Drawing.Point(12, 225);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(507, 348);
            this.panel1.TabIndex = 2;
            // 
            // cboTipoPersona
            // 
            this.cboTipoPersona.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTipoPersona.FormattingEnabled = true;
            this.cboTipoPersona.Items.AddRange(new object[] {
            "Estudiante",
            "Empleado",
            "Convenio con la biblioteca"});
            this.cboTipoPersona.Location = new System.Drawing.Point(136, 138);
            this.cboTipoPersona.Name = "cboTipoPersona";
            this.cboTipoPersona.Size = new System.Drawing.Size(339, 24);
            this.cboTipoPersona.TabIndex = 13;
            this.cboTipoPersona.SelectedIndexChanged += new System.EventHandler(this.cboTipoPersona_SelectedIndexChanged);
            // 
            // lblTipoPersona
            // 
            this.lblTipoPersona.AutoSize = true;
            this.lblTipoPersona.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoPersona.Location = new System.Drawing.Point(3, 146);
            this.lblTipoPersona.Name = "lblTipoPersona";
            this.lblTipoPersona.Size = new System.Drawing.Size(127, 16);
            this.lblTipoPersona.TabIndex = 12;
            this.lblTipoPersona.Text = "Tipo de persona:";
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(3, 236);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(80, 16);
            this.lblTipo.TabIndex = 7;
            this.lblTipo.Text = "Categoria:";
            this.lblTipo.Visible = false;
            // 
            // cboTipo
            // 
            this.cboTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTipo.FormattingEnabled = true;
            this.cboTipo.Location = new System.Drawing.Point(89, 228);
            this.cboTipo.Name = "cboTipo";
            this.cboTipo.Size = new System.Drawing.Size(386, 24);
            this.cboTipo.TabIndex = 6;
            this.cboTipo.Visible = false;
            // 
            // txtDocumentoRtrar
            // 
            this.txtDocumentoRtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocumentoRtrar.Location = new System.Drawing.Point(114, 94);
            this.txtDocumentoRtrar.Name = "txtDocumentoRtrar";
            this.txtDocumentoRtrar.Size = new System.Drawing.Size(321, 22);
            this.txtDocumentoRtrar.TabIndex = 5;
            // 
            // lblidRtrar
            // 
            this.lblidRtrar.AutoSize = true;
            this.lblidRtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidRtrar.Location = new System.Drawing.Point(3, 100);
            this.lblidRtrar.Name = "lblidRtrar";
            this.lblidRtrar.Size = new System.Drawing.Size(105, 16);
            this.lblidRtrar.TabIndex = 4;
            this.lblidRtrar.Text = "Numero de id:";
            // 
            // txtNameRtrar
            // 
            this.txtNameRtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameRtrar.Location = new System.Drawing.Point(149, 47);
            this.txtNameRtrar.Name = "txtNameRtrar";
            this.txtNameRtrar.Size = new System.Drawing.Size(340, 22);
            this.txtNameRtrar.TabIndex = 3;
            // 
            // lblNameRtrar
            // 
            this.lblNameRtrar.AutoSize = true;
            this.lblNameRtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameRtrar.Location = new System.Drawing.Point(3, 53);
            this.lblNameRtrar.Name = "lblNameRtrar";
            this.lblNameRtrar.Size = new System.Drawing.Size(140, 16);
            this.lblNameRtrar.TabIndex = 2;
            this.lblNameRtrar.Text = "Ingrese su nombre:";
            // 
            // txtCodigoRtrar
            // 
            this.txtCodigoRtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoRtrar.Location = new System.Drawing.Point(70, 3);
            this.txtCodigoRtrar.Name = "txtCodigoRtrar";
            this.txtCodigoRtrar.Size = new System.Drawing.Size(88, 22);
            this.txtCodigoRtrar.TabIndex = 1;
            // 
            // lblCodigoRtrar
            // 
            this.lblCodigoRtrar.AutoSize = true;
            this.lblCodigoRtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoRtrar.Location = new System.Drawing.Point(3, 9);
            this.lblCodigoRtrar.Name = "lblCodigoRtrar";
            this.lblCodigoRtrar.Size = new System.Drawing.Size(62, 16);
            this.lblCodigoRtrar.TabIndex = 0;
            this.lblCodigoRtrar.Text = "Código:";
            // 
            // pnelPrestarElemento
            // 
            this.pnelPrestarElemento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnelPrestarElemento.Controls.Add(this.btnPrestarElemento);
            this.pnelPrestarElemento.Controls.Add(this.txtCodigoPrestar);
            this.pnelPrestarElemento.Controls.Add(this.lblCodigoVenta);
            this.pnelPrestarElemento.Location = new System.Drawing.Point(12, 579);
            this.pnelPrestarElemento.Name = "pnelPrestarElemento";
            this.pnelPrestarElemento.Size = new System.Drawing.Size(348, 119);
            this.pnelPrestarElemento.TabIndex = 3;
            // 
            // btnPrestarElemento
            // 
            this.btnPrestarElemento.BackColor = System.Drawing.Color.White;
            this.btnPrestarElemento.Enabled = false;
            this.btnPrestarElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrestarElemento.Location = new System.Drawing.Point(236, 67);
            this.btnPrestarElemento.Name = "btnPrestarElemento";
            this.btnPrestarElemento.Size = new System.Drawing.Size(107, 47);
            this.btnPrestarElemento.TabIndex = 3;
            this.btnPrestarElemento.Text = "Prestar Elemento";
            this.btnPrestarElemento.UseVisualStyleBackColor = false;
            this.btnPrestarElemento.Click += new System.EventHandler(this.btnVentaElemento_Click);
            // 
            // txtCodigoPrestar
            // 
            this.txtCodigoPrestar.Enabled = false;
            this.txtCodigoPrestar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoPrestar.Location = new System.Drawing.Point(70, 7);
            this.txtCodigoPrestar.Name = "txtCodigoPrestar";
            this.txtCodigoPrestar.Size = new System.Drawing.Size(88, 22);
            this.txtCodigoPrestar.TabIndex = 2;
            // 
            // lblCodigoVenta
            // 
            this.lblCodigoVenta.AutoSize = true;
            this.lblCodigoVenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoVenta.Location = new System.Drawing.Point(3, 13);
            this.lblCodigoVenta.Name = "lblCodigoVenta";
            this.lblCodigoVenta.Size = new System.Drawing.Size(62, 16);
            this.lblCodigoVenta.TabIndex = 1;
            this.lblCodigoVenta.Text = "Código:";
            // 
            // pnelReservarElemento
            // 
            this.pnelReservarElemento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnelReservarElemento.Controls.Add(this.btnReservarElemento);
            this.pnelReservarElemento.Controls.Add(this.txtCodigoReservar);
            this.pnelReservarElemento.Controls.Add(this.lblCodigoReservar);
            this.pnelReservarElemento.Location = new System.Drawing.Point(366, 579);
            this.pnelReservarElemento.Name = "pnelReservarElemento";
            this.pnelReservarElemento.Size = new System.Drawing.Size(338, 119);
            this.pnelReservarElemento.TabIndex = 4;
            this.pnelReservarElemento.Paint += new System.Windows.Forms.PaintEventHandler(this.pnelReservarElemento_Paint);
            // 
            // btnReservarElemento
            // 
            this.btnReservarElemento.BackColor = System.Drawing.Color.White;
            this.btnReservarElemento.Enabled = false;
            this.btnReservarElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReservarElemento.Location = new System.Drawing.Point(226, 67);
            this.btnReservarElemento.Name = "btnReservarElemento";
            this.btnReservarElemento.Size = new System.Drawing.Size(107, 47);
            this.btnReservarElemento.TabIndex = 4;
            this.btnReservarElemento.Text = "Reservar Elemento";
            this.btnReservarElemento.UseVisualStyleBackColor = false;
            this.btnReservarElemento.Click += new System.EventHandler(this.btnReservarElemento_Click);
            // 
            // txtCodigoReservar
            // 
            this.txtCodigoReservar.Enabled = false;
            this.txtCodigoReservar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoReservar.Location = new System.Drawing.Point(64, 5);
            this.txtCodigoReservar.Name = "txtCodigoReservar";
            this.txtCodigoReservar.Size = new System.Drawing.Size(88, 22);
            this.txtCodigoReservar.TabIndex = 3;
            // 
            // lblCodigoReservar
            // 
            this.lblCodigoReservar.AutoSize = true;
            this.lblCodigoReservar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoReservar.Location = new System.Drawing.Point(3, 11);
            this.lblCodigoReservar.Name = "lblCodigoReservar";
            this.lblCodigoReservar.Size = new System.Drawing.Size(62, 16);
            this.lblCodigoReservar.TabIndex = 2;
            this.lblCodigoReservar.Text = "Código:";
            // 
            // pnelMostrarElemento
            // 
            this.pnelMostrarElemento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnelMostrarElemento.Controls.Add(this.lblMultas);
            this.pnelMostrarElemento.Controls.Add(this.lblContadorInfo);
            this.pnelMostrarElemento.Controls.Add(this.btnMultas);
            this.pnelMostrarElemento.Controls.Add(this.lblInfo);
            this.pnelMostrarElemento.Controls.Add(this.btnInfoElemento);
            this.pnelMostrarElemento.Controls.Add(this.txtCodigoInfo);
            this.pnelMostrarElemento.Controls.Add(this.lblCodigoInfo);
            this.pnelMostrarElemento.Location = new System.Drawing.Point(525, 183);
            this.pnelMostrarElemento.Name = "pnelMostrarElemento";
            this.pnelMostrarElemento.Size = new System.Drawing.Size(520, 390);
            this.pnelMostrarElemento.TabIndex = 5;
            // 
            // lblMultas
            // 
            this.lblMultas.AutoSize = true;
            this.lblMultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultas.Location = new System.Drawing.Point(6, 358);
            this.lblMultas.Name = "lblMultas";
            this.lblMultas.Size = new System.Drawing.Size(15, 16);
            this.lblMultas.TabIndex = 8;
            this.lblMultas.Text = "?";
            this.lblMultas.Visible = false;
            // 
            // lblContadorInfo
            // 
            this.lblContadorInfo.AutoSize = true;
            this.lblContadorInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContadorInfo.Location = new System.Drawing.Point(15, 68);
            this.lblContadorInfo.Name = "lblContadorInfo";
            this.lblContadorInfo.Size = new System.Drawing.Size(15, 16);
            this.lblContadorInfo.TabIndex = 7;
            this.lblContadorInfo.Text = "?";
            this.lblContadorInfo.Visible = false;
            // 
            // btnMultas
            // 
            this.btnMultas.BackColor = System.Drawing.Color.White;
            this.btnMultas.Enabled = false;
            this.btnMultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultas.Location = new System.Drawing.Point(369, 41);
            this.btnMultas.Name = "btnMultas";
            this.btnMultas.Size = new System.Drawing.Size(146, 32);
            this.btnMultas.TabIndex = 5;
            this.btnMultas.Text = "Lista de Multas";
            this.btnMultas.UseVisualStyleBackColor = false;
            this.btnMultas.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.Location = new System.Drawing.Point(15, 109);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(15, 16);
            this.lblInfo.TabIndex = 6;
            this.lblInfo.Text = "?";
            this.lblInfo.Visible = false;
            // 
            // btnInfoElemento
            // 
            this.btnInfoElemento.BackColor = System.Drawing.Color.White;
            this.btnInfoElemento.Enabled = false;
            this.btnInfoElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfoElemento.Location = new System.Drawing.Point(369, 3);
            this.btnInfoElemento.Name = "btnInfoElemento";
            this.btnInfoElemento.Size = new System.Drawing.Size(146, 32);
            this.btnInfoElemento.TabIndex = 5;
            this.btnInfoElemento.Text = "Mostrar Elemento";
            this.btnInfoElemento.UseVisualStyleBackColor = false;
            this.btnInfoElemento.Click += new System.EventHandler(this.btnInfoElemento_Click);
            // 
            // txtCodigoInfo
            // 
            this.txtCodigoInfo.Enabled = false;
            this.txtCodigoInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoInfo.Location = new System.Drawing.Point(71, 5);
            this.txtCodigoInfo.Name = "txtCodigoInfo";
            this.txtCodigoInfo.Size = new System.Drawing.Size(88, 22);
            this.txtCodigoInfo.TabIndex = 4;
            // 
            // lblCodigoInfo
            // 
            this.lblCodigoInfo.AutoSize = true;
            this.lblCodigoInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoInfo.Location = new System.Drawing.Point(3, 11);
            this.lblCodigoInfo.Name = "lblCodigoInfo";
            this.lblCodigoInfo.Size = new System.Drawing.Size(62, 16);
            this.lblCodigoInfo.TabIndex = 1;
            this.lblCodigoInfo.Text = "Código:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(756, 73);
            this.label1.TabIndex = 6;
            this.label1.Text = "MENU DE ELEMENTOS";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Location = new System.Drawing.Point(12, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1033, 165);
            this.panel5.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Tel: 222 88 88";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(384, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 29);
            this.label2.TabIndex = 8;
            this.label2.Text = "BIENVENIDOS!";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Trabajo_Final_POO.Properties.Resources.Libro;
            this.pictureBox1.Location = new System.Drawing.Point(846, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(170, 127);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.cboElemento);
            this.panel6.Controls.Add(this.btnRegistrarElemento);
            this.panel6.Location = new System.Drawing.Point(12, 183);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(507, 36);
            this.panel6.TabIndex = 9;
            // 
            // pnelDevolverElemento
            // 
            this.pnelDevolverElemento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnelDevolverElemento.Controls.Add(this.txtDiasDevolver);
            this.pnelDevolverElemento.Controls.Add(this.lblDiasDevolver);
            this.pnelDevolverElemento.Controls.Add(this.btnDevolverElemento);
            this.pnelDevolverElemento.Controls.Add(this.txtCodigoDevolver);
            this.pnelDevolverElemento.Controls.Add(this.lblCodigoDevolver);
            this.pnelDevolverElemento.Location = new System.Drawing.Point(706, 579);
            this.pnelDevolverElemento.Name = "pnelDevolverElemento";
            this.pnelDevolverElemento.Size = new System.Drawing.Size(339, 119);
            this.pnelDevolverElemento.TabIndex = 5;
            // 
            // txtDiasDevolver
            // 
            this.txtDiasDevolver.Enabled = false;
            this.txtDiasDevolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiasDevolver.Location = new System.Drawing.Point(229, 38);
            this.txtDiasDevolver.Name = "txtDiasDevolver";
            this.txtDiasDevolver.Size = new System.Drawing.Size(59, 22);
            this.txtDiasDevolver.TabIndex = 6;
            // 
            // lblDiasDevolver
            // 
            this.lblDiasDevolver.AutoSize = true;
            this.lblDiasDevolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasDevolver.Location = new System.Drawing.Point(3, 44);
            this.lblDiasDevolver.Name = "lblDiasDevolver";
            this.lblDiasDevolver.Size = new System.Drawing.Size(220, 16);
            this.lblDiasDevolver.TabIndex = 5;
            this.lblDiasDevolver.Text = "Cuantos dias tuvo el elemento:";
            // 
            // btnDevolverElemento
            // 
            this.btnDevolverElemento.BackColor = System.Drawing.Color.White;
            this.btnDevolverElemento.Enabled = false;
            this.btnDevolverElemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDevolverElemento.Location = new System.Drawing.Point(170, 81);
            this.btnDevolverElemento.Name = "btnDevolverElemento";
            this.btnDevolverElemento.Size = new System.Drawing.Size(164, 33);
            this.btnDevolverElemento.TabIndex = 4;
            this.btnDevolverElemento.Text = "Devolver Elemento";
            this.btnDevolverElemento.UseVisualStyleBackColor = false;
            this.btnDevolverElemento.Click += new System.EventHandler(this.btnDevolverElemento_Click);
            // 
            // txtCodigoDevolver
            // 
            this.txtCodigoDevolver.Enabled = false;
            this.txtCodigoDevolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoDevolver.Location = new System.Drawing.Point(68, 5);
            this.txtCodigoDevolver.Name = "txtCodigoDevolver";
            this.txtCodigoDevolver.Size = new System.Drawing.Size(88, 22);
            this.txtCodigoDevolver.TabIndex = 3;
            // 
            // lblCodigoDevolver
            // 
            this.lblCodigoDevolver.AutoSize = true;
            this.lblCodigoDevolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoDevolver.Location = new System.Drawing.Point(0, 7);
            this.lblCodigoDevolver.Name = "lblCodigoDevolver";
            this.lblCodigoDevolver.Size = new System.Drawing.Size(62, 16);
            this.lblCodigoDevolver.TabIndex = 2;
            this.lblCodigoDevolver.Text = "Código:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1056, 701);
            this.Controls.Add(this.pnelDevolverElemento);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.pnelMostrarElemento);
            this.Controls.Add(this.pnelReservarElemento);
            this.Controls.Add(this.pnelPrestarElemento);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = " Biblioteca la 45";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnelPrestarElemento.ResumeLayout(false);
            this.pnelPrestarElemento.PerformLayout();
            this.pnelReservarElemento.ResumeLayout(false);
            this.pnelReservarElemento.PerformLayout();
            this.pnelMostrarElemento.ResumeLayout(false);
            this.pnelMostrarElemento.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.pnelDevolverElemento.ResumeLayout(false);
            this.pnelDevolverElemento.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cboElemento;
        private System.Windows.Forms.Button btnRegistrarElemento;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtDocumentoRtrar;
        private System.Windows.Forms.Label lblidRtrar;
        private System.Windows.Forms.TextBox txtNameRtrar;
        private System.Windows.Forms.Label lblNameRtrar;
        private System.Windows.Forms.TextBox txtCodigoRtrar;
        private System.Windows.Forms.Label lblCodigoRtrar;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.ComboBox cboTipo;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Panel pnelPrestarElemento;
        private System.Windows.Forms.Button btnPrestarElemento;
        private System.Windows.Forms.TextBox txtCodigoPrestar;
        private System.Windows.Forms.Label lblCodigoVenta;
        private System.Windows.Forms.Panel pnelReservarElemento;
        private System.Windows.Forms.Button btnReservarElemento;
        private System.Windows.Forms.TextBox txtCodigoReservar;
        private System.Windows.Forms.Label lblCodigoReservar;
        private System.Windows.Forms.Panel pnelMostrarElemento;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnInfoElemento;
        private System.Windows.Forms.TextBox txtCodigoInfo;
        private System.Windows.Forms.Label lblCodigoInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnelDevolverElemento;
        private System.Windows.Forms.Button btnDevolverElemento;
        private System.Windows.Forms.TextBox txtCodigoDevolver;
        private System.Windows.Forms.Label lblCodigoDevolver;
        private System.Windows.Forms.TextBox txtDiasDevolver;
        private System.Windows.Forms.Label lblDiasDevolver;
        private System.Windows.Forms.Label lblContadorInfo;
        private System.Windows.Forms.Button btnMultas;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMultas;
        private System.Windows.Forms.Label lblTipoPersona;
        private System.Windows.Forms.ComboBox cboTipoPersona;
    }
}

