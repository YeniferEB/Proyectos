﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabajo_Final_POO
{
    public class Video:Elementos
    {
        public Video() { }

        public override string MostrarInformacion()
        {
            return "CÓDIGO: " + Codigo + "\nNOMBRE DE ELEMENTO: " + nameElemento + "\nNOMBRE DE LA PERSONA A CARGO DEL ELEMENTO: " +
                namePersona + "\nNUMERO DE DOCUMENTO: " + numDocumento + "\nDIAS QUE SE PRESTO EL ELEMENTO: " + DiasEntregar +
                "\nCATEGORIA DEL ELEMENTO: " + Tipo + "\nTIPO DE PERSONA: " + tipo_Persona + "\nVALOR DE LA MULTA: " + vlr_Multa + "$";
        }
        public override string Multas()
        {
            if (DiasEntregar > 7)
            {
                msg_Multa = "USTED HA SIDO MULTADO POR NO ENTREGAR EL VIDEO CASSETE EN 7 DIAS: VALOR: 10000";
            }
            return (msg_Multa);
        }
        public override double Valor_Multa()
        {
            double total = 0;
            if (DiasEntregar > 7)
            {
                total = total + 10000;
            }
            return (total);
        }
        public override string DevolverElemento()
        {
            // ----- VIDEO ROMANTICO -----
            if (Tipo == "After")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL VIDEO ROMANTICO: AFTER!";
            }
            // ----- VIDEO DE ACCIÓN -----
            else if (Tipo == "Spider-man")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL VIDEO DE ACCION: SPIDER-MAN!";
            }
            // ----- VIDEO DE TERROR -----
            else if (Tipo == "Saw")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL VIDEO DE TERROR: SAW!";
            }
            // ----- VIDEO DE JUEGOS -----
            else if (Tipo == "Resident evil")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL VIDEO DE JUEGOS: RESIDENT EVIL!";
            }
            // ----- VIDEO DE ANIME -----
            else if (Tipo == "Yu-gi-oh!")
            {
                msg_Tipo = "GRACIAS POR DEVOLVER EL VIDEO DE ANIME: YU-GI-OH!";
            }
            else
            {
                msg_Tipo = "ERROR. EL VIDEO NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
        public override string Reservar()
        {
            // ----- VIDEO ROMANTICO -----
            if (Tipo == "After")
            {
                msg_Tipo = "USTED RESERVO EL VIDEO ROMANTICO: AFTER!";
            }
            // ----- VIDEO DE ACCIÓN -----
            else if (Tipo == "Spider-man")
            {
                msg_Tipo = "USTED RESERVO EL VIDEO DE ACCION: SPIDER-MAN!";
            }
            // ----- VIDEO DE TERROR -----
            else if (Tipo == "Saw")
            {
                msg_Tipo = "USTED RESERVO EL VIDEO DE TERROR: SAW!";
            }
            // ----- VIDEO DE JUEGOS -----
            else if (Tipo == "Resident evil")
            {
                msg_Tipo = "USTED RESERVO EL VIDEO DE JUEGOS: RESIDENT EVIL!";
            }
            // ----- VIDEO DE ANIME -----
            else if (Tipo == "Yu-gi-oh!")
            {
                msg_Tipo = "USTED RESERVO EL VIDEO DE ANIME: YU-GI-OH!";
            }
            else
            {
                msg_Tipo = "ERROR. EL VIDEO NO EXISTE. INTETE NUEVAMENTE";
            }
            return (msg_Tipo);
        }
    }
}
